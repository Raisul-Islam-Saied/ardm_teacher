import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Camera, Check, Loader2, Search } from 'lucide-react';
import { Input } from './UIComponents';
import { processImageToSquare500 } from '../services/cloudinaryClient';
import { fetchDistricts, fetchDivisions, fetchUnions, fetchUpazilas } from '../services/bdAddressApi';
import { studentApi } from '../services/studentApiService';
import { extractApiErrorMessage } from '../services/axiosClient';
import {
  CLASS_LIST_BN,
  generateStudentId,
  isSeniorClass,
  legacyToFormState,
  mapServerFieldErrors,
  toUiClass
} from '../models/studentModel';

// ==============================================
// 5. COMPLEX COMPONENTS (VALIDATED & STACKED)
// ==============================================

// ---- Validation rules (mirror the server: validators/student.validator.js) ----
const RX = {
  BN_NAME: /^[\u0980-\u09FF][\u0980-\u09FF\s.'-]{1,59}$/,
  EN_NAME: /^[A-Za-z][A-Za-z\s.'-]{2,59}$/,
  MOBILE: /^01[3-9]\d{8}$/,
  BRN: /^\d{17}$/,
  BN_PLACE: /^[\u0980-\u09FF\s.'-]{2,80}$/,
  EN_PLACE: /^[A-Za-z\s.'-]{2,80}$/,
  BN_HOUSE: /^[\u0980-\u09FF0-9\s.,'-]{2,80}$/,
  EN_HOUSE: /^[A-Za-z0-9\s.,'-]{2,80}$/,
  WARD: /^\d{1,3}$/
};
const FAKE = [/^(\d)\1+$/, /^123456789/, /^987654321/, /^0123456789/];
const isFake = (v) => FAKE.some((r) => r.test(String(v)));
const collapse = (v) => String(v ?? '').replace(/\s+/g, ' ').trim();

const FIELD_STEP = {
  sessionYear: 1, studentNameBn: 1, studentNameEn: 1, roll: 1, classBn: 1, group: 1, gender: 1, brn: 1, dob: 1,
  fatherNameBn: 2, fatherNameEn: 2, motherNameBn: 2, motherNameEn: 2, whatsappNumber: 2, emergencyNumber: 2,
  houseNameBn: 3, houseNameEn: 3, villageBn: 3, villageEn: 3, unionBn: 3, unionEn: 3, wardNo: 3,
  upazilaBn: 3, upazilaEn: 3, districtBn: 3, districtEn: 3, imageUrl: 4
};

const SelectBox = ({ label, value, onChange, options, disabled, loading, placeholder = 'Select...' }) => (
  <div className="relative pt-1 w-full">
    <label className="text-[10px] font-bold text-gray-400 uppercase ml-1 mb-0.5 block flex justify-between">
      {label}
      {loading && <Loader2 size={12} className="animate-spin text-slate-400" />}
    </label>
    <select
      disabled={disabled || loading}
      className={`w-full p-4 bg-gray-50 rounded-xl font-bold outline-none border border-transparent focus:bg-white focus:ring-2 focus:ring-slate-900 ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      value={value}
      onChange={(e) => onChange(e.target.value)}
    >
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o.id} value={o.id}>{o.nameEn} — {o.nameBn}</option>
      ))}
    </select>
  </div>
);

const FullForm = ({ initialData, currentUser, onSave, onCancel, showToast, isAdmin }) => {
  const isUpdate = !!initialData;
  const defaultState = {
    sessionYear: (() => {
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth(); // 0 = January, 9 = October
      return (currentMonth >= 9 ? currentYear + 1 : currentYear).toString();
    })(),
    studentId: '',
    studentNameBn: '', studentNameEn: '', gender: '', roll: '', classBn: '', group: '', brn: '', dob: '', bloodGroup: '',
    fatherNameBn: '', motherNameBn: '', whatsappNumber: '', emergencyNumber: '',
    fatherNameEn: '', motherNameEn: '',
    houseNameBn: '', villageBn: 'মীরেরখীল', unionBn: 'সরফভাটা', wardNo: '', upazilaBn: 'রাঙ্গুনিয়া', districtBn: 'চট্টগ্রাম',
    imageUrl: '',
    villageEn: 'Mirerkhil',
    unionEn: 'Sarfbhata',
    upazilaEn: 'Rangunia',
    districtEn: 'Chattogram',
    houseNameEn: '',
    divisionBn: '', divisionEn: ''
  };

  const [form, setForm] = useState(defaultState);
  const [step, setStep] = useState(1);
  const [errors, setErrors] = useState({});
  const [imgPreview, setImgPreview] = useState(null);
  const [saving, setSaving] = useState(false);
  const [migration, setMigration] = useState(null); // { studentCode, admissionDate }
  const [legacyId, setLegacyId] = useState('');
  const [legacyBusy, setLegacyBusy] = useState(false);
  const formRef = useRef(null);

  // ---- BD geo cascade (Division → District → Upazila → Union) ----
  const [geo, setGeo] = useState({ divisions: [], districts: [], upazilas: [], unions: [] });
  const [geoSel, setGeoSel] = useState({ division: '', district: '', upazila: '', union: '' });
  const [geoLoading, setGeoLoading] = useState('');
  const [geoError, setGeoError] = useState('');

  const geoFail = (e) => { if (e?.name !== 'AbortError') setGeoError(e.message || 'ঠিকানার তালিকা লোড করা যায়নি'); };

  useEffect(() => {
    if (step !== 3 || geo.divisions.length > 0) return undefined;
    const ac = new AbortController();
    setGeoLoading('division');
    fetchDivisions(ac.signal)
      .then((list) => { setGeo((g) => ({ ...g, divisions: list })); setGeoError(''); })
      .catch(geoFail)
      .finally(() => setGeoLoading(''));
    return () => ac.abort();
  }, [step]);

  const pickGeo = async (level, id) => {
    const order = ['division', 'district', 'upazila', 'union'];
    const keyOf = { division: 'divisions', district: 'districts', upazila: 'upazilas', union: 'unions' };
    const item = geo[keyOf[level]].find((x) => x.id === id);
    const idx = order.indexOf(level);

    // নিচের লেভেলগুলো রিসেট
    const resetSel = { ...geoSel, [level]: id };
    const resetGeo = { ...geo };
    order.slice(idx + 1).forEach((lv) => { resetSel[lv] = ''; resetGeo[keyOf[lv]] = []; });
    setGeoSel(resetSel);
    setGeo(resetGeo);

    if (!item) return;
    const fieldsOf = {
      division: ['divisionBn', 'divisionEn'],
      district: ['districtBn', 'districtEn'],
      upazila: ['upazilaBn', 'upazilaEn'],
      union: ['unionBn', 'unionEn']
    };
    const [bnKey, enKey] = fieldsOf[level];
    setForm((p) => ({ ...p, [bnKey]: item.nameBn, [enKey]: item.nameEn }));
    setErrors((p) => ({ ...p, [bnKey]: '', [enKey]: '' }));

    const next = order[idx + 1];
    if (!next) return;
    const fetcher = { district: fetchDistricts, upazila: fetchUpazilas, union: fetchUnions }[next];
    setGeoLoading(next);
    try {
      const list = await fetcher(id);
      setGeo((g) => ({ ...g, [keyOf[next]]: list }));
      setGeoError('');
    } catch (e) { geoFail(e); } finally { setGeoLoading(''); }
  };

  // ---- Draft (only for brand-new admission) ----
  useEffect(() => {
    const saved = localStorage.getItem("draftStudentForm");
    if (!initialData && saved) {
      try { setForm({ ...defaultState, ...JSON.parse(saved) }); } catch (e) {}
    }
  }, []);
  useEffect(() => {
    if (!initialData) {
      localStorage.setItem("draftStudentForm", JSON.stringify(form));
    }
  }, [form]);

  useEffect(() => {
    if (initialData) {
      const parseDate = (dStr) => {
        if (!dStr) return '';

        // যদি already YYYY-MM-DD হয়
        if (/^\d{4}-\d{2}-\d{2}$/.test(dStr)) {
          return dStr;
        }

        // অন্য সব কিছুর জন্য safe parse
        const d = new Date(dStr);
        if (isNaN(d.getTime())) return '';

        // লোকাল ডেট বানিয়ে string
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');

        return `${y}-${m}-${day}`;
      };

      setForm({
        sessionYear: initialData.Session || '',
        studentId: initialData.ID || '',
        studentNameBn: initialData.StudentNameBn || '',
        studentNameEn: initialData.StudentNameEn || '',
        gender: initialData.Gender || '',
        roll: initialData.Roll || '',
        classBn: toUiClass(initialData.ClassBn || ''),
        group: initialData.Group || '',
        brn: initialData.BRN || '',
        dob: parseDate(initialData.DOB),
        bloodGroup: initialData.BloodGroup || '',
        fatherNameBn: initialData.FatherNameBn || '',
        fatherNameEn: initialData.FatherNameEn || '',
        motherNameBn: initialData.MotherNameBn || '',
        motherNameEn: initialData.MotherNameEn || '',
        whatsappNumber: initialData.WhatsApp || '',
        emergencyNumber: initialData.EmergencyNo || '',
        houseNameBn: initialData.HouseNameBn || '',
        houseNameEn: initialData.HouseNameEn || '',
        villageBn: initialData.VillageBn || '',
        villageEn: initialData.VillageEn || '',
        unionBn: initialData.UnionBn || '',
        unionEn: initialData.UnionEn || '',
        wardNo: initialData.WardNo || '',
        upazilaBn: initialData.UpazilaBn || '',
        upazilaEn: initialData.UpazilaEn || '',
        districtBn: initialData.DistrictBn || '',
        districtEn: initialData.DistrictEn || '',
        divisionBn: '', divisionEn: '',
        imageUrl: initialData.ImageURL || ''
      });
      setImgPreview(initialData.ImageURL || null);
    } else {
      setForm((f) => (f.studentNameBn || f.brn ? f : defaultState));
      setImgPreview(null);
    }
  }, [initialData]);

  useEffect(() => {
    if (!initialData && currentUser?.role === "Class") {
      setForm(f => ({ ...f, classBn: currentUser.classBn }));
    }
  }, [initialData, currentUser]);

  // SMART ID GENERATION (same algorithm as server — server's ID is final)
  useEffect(() => {
    if (!initialData && !migration && form.sessionYear && form.dob && form.classBn && form.roll) {
      try {
        const id = generateStudentId(form.sessionYear, form.dob, form.classBn, form.roll);
        setForm(prev => ({ ...prev, studentId: id }));
      } catch (e) {}
    }
  }, [form.sessionYear, form.dob, form.classBn, form.roll, initialData, migration]);

  // গ্রুপ শুধু ৯ম/১০ম শ্রেণির জন্য — অন্য ক্লাসে নিজে থেকে ফাঁকা হবে
  useEffect(() => {
    if (form.classBn && !isSeniorClass(form.classBn) && form.group) {
      setForm((p) => ({ ...p, group: '' }));
    }
  }, [form.classBn]);

  // ---- field-level validation (live) ----
  const fieldError = (f, v, all = form) => {
    const val = collapse(v);
    switch (f) {
      case 'studentNameBn':
        if (!val) return 'নাম আবশ্যক';
        return RX.BN_NAME.test(val) ? '' : 'শুধু বাংলা (২-৬০ অক্ষর)';
      case 'studentNameEn':
        if (!val) return 'English name required';
        return RX.EN_NAME.test(val) ? '' : 'English only (3-60)';
      case 'fatherNameBn': case 'motherNameBn':
        if (!val) return f === 'fatherNameBn' ? 'পিতার নাম আবশ্যক' : 'মাতার নাম আবশ্যক';
        return RX.BN_NAME.test(val) ? '' : 'বাংলায় লিখুন (২-৬০ অক্ষর)';
      case 'fatherNameEn': case 'motherNameEn':
        if (!val) return f === 'fatherNameEn' ? 'Father name required' : 'Mother name required';
        return RX.EN_NAME.test(val) ? '' : 'English only (3-60)';
      case 'whatsappNumber': case 'emergencyNumber':
        if (!val) return f === 'whatsappNumber' ? 'Mobile number required' : 'Emergency number required';
        return RX.MOBILE.test(val) ? '' : 'Invalid mobile (01XXXXXXXXX)';
      case 'roll': {
        if (!val) return 'Roll required';
        const n = Number(val);
        return Number.isInteger(n) && n >= 1 && n <= 500 ? '' : 'Roll must be 1-500';
      }
      case 'classBn': return val ? '' : 'Class required';
      case 'gender': return val ? '' : 'Gender required';
      case 'group':
        if (isSeniorClass(all.classBn) && !val) return 'গ্রুপ আবশ্যক (৯ম/১০ম)';
        return '';
      case 'brn':
        if (!val) return 'BRN required';
        if (!RX.BRN.test(val)) return '17 digit BRN';
        if (isFake(val)) return 'বৈধ BRN দিন';
        if (all.dob && String(new Date(all.dob).getFullYear()) !== val.slice(0, 4)) return 'BRN-এর প্রথম ৪ সংখ্যা জন্মসালের সাথে মিলছে না';
        return '';
      case 'dob': {
        if (!val) return 'Date of birth required';
        const d = new Date(val);
        if (isNaN(d.getTime())) return 'সঠিক তারিখ দিন';
        if (d > new Date()) return 'ভবিষ্যতের তারিখ হবে না';
        const age = (new Date() - d) / (365.25 * 24 * 3600 * 1000);
        return age < 2.5 || age > 22 ? 'Age must be 2.5-22' : '';
      }
      case 'sessionYear': return /^20\d{2}$/.test(val) ? '' : 'সঠিক সেশন (যেমন 2026)';
      case 'houseNameBn':
        if (!val) return 'বাড়ির নাম আবশ্যক';
        return RX.BN_HOUSE.test(val) ? '' : 'বাংলায় লিখুন (২-৮০ অক্ষর)';
      case 'houseNameEn':
        return RX.EN_HOUSE.test(val) ? '' : 'House Name English required';
      case 'villageBn': case 'unionBn': case 'upazilaBn': case 'districtBn': {
        const label = { villageBn: 'গ্রাম', unionBn: 'ইউনিয়ন', upazilaBn: 'উপজেলা', districtBn: 'জেলা' }[f];
        if (!val) return `${label} আবশ্যক`;
        return RX.BN_PLACE.test(val) ? '' : 'বাংলায় লিখুন (২-৮০ অক্ষর)';
      }
      case 'villageEn': case 'unionEn': case 'upazilaEn': case 'districtEn': {
        const label = { villageEn: 'Village', unionEn: 'Union', upazilaEn: 'Upazila', districtEn: 'District' }[f];
        return RX.EN_PLACE.test(val) ? '' : `${label} Name English required`;
      }
      case 'wardNo':
        if (!val) return 'Ward Number required';
        return RX.WARD.test(val) ? '' : 'Ward 1-999 (number only)';
      default: return '';
    }
  };

  const update = (f, v) => {
    if (f === "roll") {
      v = parseInt(v) || "";
      if (v > 500) v = 500;
    }
    if (f === "whatsappNumber" || f === "emergencyNumber") {
      v = String(v).replace(/[^0-9]/g, '').slice(0, 11); // শুধু সংখ্যা রাখবে
    }
    if (f === "brn") {
      v = String(v).replace(/[^0-9]/g, '').slice(0, 17);
    }
    if (f === "wardNo") {
      v = String(v).replace(/[^0-9]/g, '').slice(0, 3);
    }

    const next = { ...form, [f]: v };
    setForm(next);

    // লাইভ এরর (ডিপেন্ডেন্ট ফিল্ডসহ)
    const upd = { [f]: fieldError(f, v, next) };
    if (f === 'dob' && next.brn) upd.brn = fieldError('brn', next.brn, next);
    if (f === 'classBn') upd.group = fieldError('group', next.group, next);
    setErrors(prev => ({ ...prev, ...upd }));
  };

  // ---- step validation ----
  const stepFields = {
    1: ['sessionYear', 'studentNameBn', 'studentNameEn', 'roll', 'classBn', 'group', 'gender', 'brn', 'dob'],
    2: ['fatherNameBn', 'fatherNameEn', 'motherNameBn', 'motherNameEn', 'whatsappNumber', 'emergencyNumber'],
    3: ['houseNameBn', 'villageBn', 'unionBn', 'wardNo', 'upazilaBn', 'districtBn', 'houseNameEn', 'villageEn', 'unionEn', 'upazilaEn', 'districtEn'],
    4: []
  };

  const focusField = (name) => {
    setTimeout(() => {
      const el = formRef.current?.querySelector(`[name="${name}"]`) || document.querySelector(`[name="${name}"]`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.focus?.();
      }
    }, 60);
  };

  const validate = (targetStep = step) => {
    let e = {};
    (stepFields[targetStep] || []).forEach((f) => {
      const msg = fieldError(f, form[f]);
      if (msg) e[f] = msg;
    });
    if (Object.keys(e).length > 0) {
      focusField(Object.keys(e)[0]);
    }
    setErrors((prev) => ({ ...prev, ...e }));
    return Object.keys(e).length === 0;
  };

  const handleNext = () => { if (validate()) setStep(s => s + 1); };

  const handleSubmit = async () => {
    // সব ধাপ একসাথে যাচাই — প্রথম ভুল ধাপে ফিরে যাবে
    for (const s of [1, 2, 3]) {
      if (!validate(s)) { setStep(s); return; }
    }
    setSaving(true);
    const res = await onSave(form, { migration });
    setSaving(false);

    if (res && res.ok === false && res.fieldErrors?.length) {
      const { errors: srvErr, firstStep, unmapped } = mapServerFieldErrors(res.fieldErrors);
      if (Object.keys(srvErr).length) {
        setErrors((prev) => ({ ...prev, ...srvErr }));
        if (firstStep) setStep(firstStep);
        focusField(Object.keys(srvErr)[0]);
      }
      if (unmapped.length && showToast) showToast(unmapped[0], 'error');
    }
  };

  // ---- Photo: square check (tolerance 20px) → 500×500 JPEG ----
  const handleImage = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const out = await processImageToSquare500(file, { squareTolerance: 20, quality: 0.85 });
      setImgPreview(out.dataUrl);
      update('imageUrl', out.dataUrl);
      setErrors((p) => ({ ...p, imageUrl: '' }));
    } catch (err) {
      showToast(err.message, "error");
      e.target.value = "";
    }
  };

  // ---- Migration from the old Google Sheet (admin, new admission only) ----
  const handleLegacyLookup = async () => {
    const code = legacyId.trim();
    if (!/^\d{10}$/.test(code)) return showToast('১০ ডিজিটের পুরনো স্টুডেন্ট আইডি দিন', 'error');
    setLegacyBusy(true);
    try {
      const res = await studentApi.legacyLookup(code);
      if (res.alreadyMigrated) {
        showToast(`এই আইডি আগেই মাইগ্রেট হয়েছে (${res.existingStudent?.fullNameBng || code})`, 'error');
        return;
      }
      const f = legacyToFormState(res.autoFillData);
      setForm((p) => ({ ...defaultState, ...f, divisionBn: '', divisionEn: '' }));
      setImgPreview(f.imageUrl || null);
      setMigration({ studentCode: res.autoFillData.studentCode, admissionDate: res.autoFillData.admissionDate });
      setErrors({});
      showToast(res.message || 'পুরনো তথ্য পাওয়া গেছে — যাচাই করে সংরক্ষণ করুন', 'success');
    } catch (err) {
      showToast(extractApiErrorMessage(err, 'পুরনো শিট থেকে তথ্য আনা যায়নি'), 'error');
    } finally {
      setLegacyBusy(false);
    }
  };

  const classLocked = currentUser?.role === "Class";

  return (
    <div ref={formRef} className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 min-h-[70vh] flex flex-col">
      <div className="flex justify-between mb-8 px-2">
        {[1, 2, 3, 4].map(s => <div key={s} className={`h-2 rounded-full transition-all duration-300 ${step >= s ? 'w-full bg-slate-900 mx-1' : 'w-full bg-gray-100 mx-1'}`} />)}
      </div>

      <div className="flex-1">
        {step === 1 && (
          <div className="space-y-4 animate-in fade-in slide-in-from-right-8 duration-300">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Step 1: Basic Info</h3>

            {!isUpdate && isAdmin && (
              <div className="p-4 bg-amber-50 rounded-xl border border-amber-100">
                <p className="text-[10px] font-bold text-amber-700 uppercase tracking-widest mb-2">
                  {migration ? `পুরনো শিট থেকে আনা হয়েছে (ID: ${migration.studentCode})` : 'পুরনো শিট থেকে মাইগ্রেট (ঐচ্ছিক)'}
                </p>
                <div className="flex gap-2">
                  <input
                    inputMode="numeric"
                    maxLength={10}
                    value={legacyId}
                    onChange={(e) => setLegacyId(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="পুরনো ১০ ডিজিটের আইডি"
                    className="flex-1 p-3 bg-white rounded-xl font-bold outline-none border border-amber-100 focus:ring-2 focus:ring-amber-400 text-sm"
                  />
                  <button
                    type="button"
                    onClick={handleLegacyLookup}
                    disabled={legacyBusy}
                    className="px-4 rounded-xl bg-amber-500 text-white font-bold text-sm flex items-center gap-1 disabled:opacity-60"
                  >
                    {legacyBusy ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />} আনুন
                  </button>
                </div>
              </div>
            )}

            <Input name="sessionYear" label="Session" type="number" val={form.sessionYear} set={v => update('sessionYear', v)} error={errors.sessionYear} />

            {/* STACKED INPUTS (One per line) */}
            <Input name="studentNameBn" label="নাম (বাংলা)" val={form.studentNameBn} set={v => update('studentNameBn', v)} error={errors.studentNameBn} />
            <Input name="studentNameEn" label="Name (English)" val={form.studentNameEn} set={v => update('studentNameEn', v)} error={errors.studentNameEn} />

            <Input name="roll" label="Roll" type="number" min="1" max="500" val={form.roll} set={v => update('roll', v)} error={errors.roll} />

            <div className="relative pt-1 w-full">
              <label className="text-[10px] font-bold text-gray-400 uppercase ml-1 block">Class</label>
              <select
                name="classBn"
                disabled={classLocked}
                className={`w-full p-4 bg-gray-50 rounded-xl font-bold outline-none border ${errors.classBn ? 'border-red-500' : 'border-transparent'} ${classLocked ? 'opacity-60 cursor-not-allowed bg-gray-200 text-gray-500' : ''}`}
                value={form.classBn}
                onChange={e => update('classBn', e.target.value)}
              >
                <option value="">Select...</option>
                {CLASS_LIST_BN.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              {errors.classBn && (
                <p className="text-red-500 text-xs font-bold mt-1">
                  {errors.classBn}
                </p>
              )}
            </div>

            {isSeniorClass(form.classBn) && (
              <div className="relative pt-1 w-full">
                <label className="text-[10px] font-bold text-gray-400 uppercase ml-1 block">Group</label>
                <select
                  name="group"
                  className={`w-full p-4 bg-gray-50 rounded-xl font-bold outline-none border ${errors.group ? 'border-red-500' : 'border-transparent'}`}
                  value={form.group}
                  onChange={e => update('group', e.target.value)}
                >
                  <option value="">Select...</option>
                  <option value="General">General</option>
                  <option value="Science">Science</option>
                  <option value="Muzabbid">Muzabbid</option>
                </select>
                {errors.group && (
                  <p className="text-red-500 text-xs font-bold mt-1">{errors.group}</p>
                )}
              </div>
            )}

            <div className="relative pt-1 w-full">
              <label className="text-[10px] font-bold text-gray-400 uppercase ml-1 block">
                Gender
              </label>
              <select
                name="gender"
                className={`w-full p-4 bg-gray-50 rounded-xl font-bold outline-none border 
      ${errors.gender ? 'border-red-500' : 'border-transparent'}`}
                value={form.gender}
                onChange={e => update('gender', e.target.value)}
              >
                <option value="">Select...</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
              {errors.gender && (
                <p className="text-red-500 text-xs font-bold mt-1">
                  {errors.gender}
                </p>
              )}
            </div>
            <Input name="brn" label="BIRTH REGISTRATION NUMBER" inputMode="numeric" maxLength={17} type="text" val={form.brn} set={v => update('brn', v)} error={errors.brn} />
            <Input name="dob" label="DATE OF BIRTH" type="date" val={form.dob} set={v => update('dob', v)} error={errors.dob} />

            <div className="relative pt-1 w-full">
              <label className="text-[10px] font-bold text-gray-400 uppercase ml-1">Blood Group</label>
              <select
                name="bloodGroup"
                className={`w-full p-4 bg-gray-50 rounded-xl font-bold outline-none border ${errors.bloodGroup ? 'border-red-500' : 'border-transparent'
                  }`}
                value={form.bloodGroup}
                onChange={e => update('bloodGroup', e.target.value)}
              >

                <option value="">N/A</option>
                {['A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'AB-'].map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              {errors.bloodGroup && (
                <p className="text-red-500 text-xs font-bold mt-1">
                  {errors.bloodGroup}
                </p>
              )}

            </div>

            <div className="mt-2 p-4 bg-blue-50 rounded-xl border border-blue-100">
              <Input disabled name="studentId" label="Student ID (Auto)" type="text" val={form.studentId} set={v => update('studentId', v)} error={errors.studentId} />
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4 animate-in fade-in slide-in-from-right-8 duration-300">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Step 2: Parents Info</h3>
            <Input name="fatherNameBn" label="পিতার নাম (বাংলা)" val={form.fatherNameBn} set={v => update('fatherNameBn', v)} error={errors.fatherNameBn} />

            <Input name="fatherNameEn" label="Father Name (English)"
              val={form.fatherNameEn}
              set={v => update('fatherNameEn', v)}
              error={errors.fatherNameEn} />

            <Input name="motherNameBn" label="মাতার নাম (বাংলা)" val={form.motherNameBn} set={v => update('motherNameBn', v)} error={errors.motherNameBn} />

            <Input name="motherNameEn" label="Mother Name (English)"
              val={form.motherNameEn}
              set={v => update('motherNameEn', v)}
              error={errors.motherNameEn} />

            <Input name="whatsappNumber" label="Mobile (WhatsApp)" type="tel" inputMode="numeric" maxLength={11} val={form.whatsappNumber} set={v => update('whatsappNumber', v)} error={errors.whatsappNumber} />
            <Input
              name="emergencyNumber"
              label="Emergency No"
              type="tel"
              inputMode="numeric"
              maxLength={11}
              val={form.emergencyNumber}
              set={v => update('emergencyNumber', v)}
              error={errors.emergencyNumber}
            />

          </div>
        )}

        {step === 3 && (
          <div className="space-y-4 animate-in fade-in slide-in-from-right-8 duration-300">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Step 3: Address (Bangla Only)</h3>

            {/* বাংলাদেশ জিও-ঠিকানা: নির্বাচন করলে বাংলা ও ইংরেজি দুই ঘরই পূরণ হয় */}
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 space-y-3">
              <p className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest">ঠিকানা বাছাই (Division → Union)</p>
              {geoError && <p className="text-red-500 text-xs font-bold">{geoError}</p>}
              <SelectBox label="Division" value={geoSel.division} loading={geoLoading === 'division'} options={geo.divisions} onChange={(id) => pickGeo('division', id)} />
              <SelectBox label="District" value={geoSel.district} disabled={!geoSel.division} loading={geoLoading === 'district'} options={geo.districts} onChange={(id) => pickGeo('district', id)} />
              <SelectBox label="Upazila" value={geoSel.upazila} disabled={!geoSel.district} loading={geoLoading === 'upazila'} options={geo.upazilas} onChange={(id) => pickGeo('upazila', id)} />
              <SelectBox label="Union" value={geoSel.union} disabled={!geoSel.upazila} loading={geoLoading === 'union'} options={geo.unions} onChange={(id) => pickGeo('union', id)} />
            </div>

            <Input
              name="houseNameBn"
              label="বাড়ির নাম (বাংলা)"
              val={form.houseNameBn}
              set={v => update('houseNameBn', v)}
              error={errors.houseNameBn}
            />
            <Input name="villageBn" label="গ্রাম (বাংলা)" val={form.villageBn} set={v => update('villageBn', v)} error={errors.villageBn} />
            <Input name="unionBn" label="ইউনিয়ন (বাংলা)" val={form.unionBn} set={v => update('unionBn', v)} error={errors.unionBn} />

            <Input name="wardNo" label="Ward No" type="text" inputMode="numeric" maxLength={3} val={form.wardNo} set={v => update('wardNo', v)} error={errors.wardNo} />
            <Input name="upazilaBn" label="উপজেলা (বাংলা)" val={form.upazilaBn} set={v => update('upazilaBn', v)} error={errors.upazilaBn} />

            <Input name="districtBn" label="জেলা (বাংলা)" val={form.districtBn} set={v => update('districtBn', v)} error={errors.districtBn} />

            <>
              <Input name="houseNameEn" label="House Name (English)"
                val={form.houseNameEn}
                set={v => update('houseNameEn', v)}
                error={errors.houseNameEn}
              />

              <Input name="villageEn" label="Village (English)"
                val={form.villageEn}
                set={v => update('villageEn', v)}
                error={errors.villageEn}
              />

              <Input name="unionEn" label="Union (English)"
                val={form.unionEn}
                set={v => update('unionEn', v)}
                error={errors.unionEn}
              />

              <Input name="upazilaEn" label="Upazila (English)"
                val={form.upazilaEn}
                set={v => update('upazilaEn', v)}
                error={errors.upazilaEn}
              />

              <Input name="districtEn" label="District (English)"
                val={form.districtEn}
                set={v => update('districtEn', v)}
                error={errors.districtEn}
              />

            </>
          </div>
        )}

        {step === 4 && (
          <div className="flex flex-col items-center animate-in fade-in zoom-in duration-300 py-6">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-8">Step 4: Student Photo</h3>
            <div className={`relative w-56 h-56 bg-gray-100 rounded-full flex items-center justify-center border-[6px] shadow-2xl ring-1 overflow-hidden ${errors.imageUrl ? 'border-red-500 ring-red-200' : 'border-white ring-gray-100'}`}>
              {imgPreview ? <img src={imgPreview} className="w-full h-full object-cover" /> : <Camera size={48} className="text-gray-300" />}
              <input name="imageUrl" type="file" onChange={handleImage} className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" />
            </div>
            {errors.imageUrl && <p className="text-red-500 text-xs font-bold mt-2">{typeof errors.imageUrl === 'string' && errors.imageUrl.length > 1 ? errors.imageUrl : 'ছবি আবশ্যক'}</p>}
            <p className="mt-8 text-sm text-gray-500 font-medium bg-gray-50 px-4 py-2 rounded-full text-center">Tap photo to upload <br /><span className="text-xs text-gray-400">(Square Only)</span></p>
          </div>
        )}
      </div>

      <div className="flex justify-between mt-8 pt-6 border-t border-gray-100">
        {step > 1 ? <button id="formBackBtn" onClick={() => setStep(s => s - 1)} className="font-bold text-gray-400 px-6 py-3 bg-gray-50 rounded-xl">
          Back
        </button> : <button id="formBackBtn" onClick={onCancel} className="font-bold text-red-400 px-4 py-3">
          Cancel
        </button>
        }
        {step < 4 ? (
          <button onClick={handleNext} className="bg-slate-900 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2">Next <ArrowRight size={18} /></button>
        ) : (
          <button onClick={handleSubmit} disabled={saving} className="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 shadow-xl shadow-blue-200 disabled:opacity-60">
            {saving ? <Loader2 size={18} className="animate-spin" /> : <>Submit <Check size={18} /></>}
          </button>
        )}
      </div>
    </div>
  );
};

export default FullForm;
