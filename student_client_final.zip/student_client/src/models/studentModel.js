/**
 * ARDM Student Portal — Student Model (MongoDB <-> original UI adapter)
 * Server docs use fullNameBng / studentCode / ... ; the original UI (DetailView, exports,
 * filters, ID cards) uses StudentNameBn / ID / ... — this file converts both ways.
 */
import { CLASS_ORDER } from '../config/systemConfig';

// ------------------------------------------------------------------
// Original helpers (verbatim)
// ------------------------------------------------------------------
export const getDaysUntilBirthday = (dobStr) => {
  if (!dobStr) return null;
  const dob = new Date(dobStr);
  if (isNaN(dob.getTime())) return null;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let next = new Date(today.getFullYear(), dob.getMonth(), dob.getDate());
  next.setHours(0, 0, 0, 0);

  if (next < today) {
    next = new Date(today.getFullYear() + 1, dob.getMonth(), dob.getDate());
  }

  return Math.round((next - today) / (1000 * 60 * 60 * 24));
};
export const formatDate = (dateStr) => {
  if (!dateStr) return 'N/A';

  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;

  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
};

export const REGEX = {
  BANGLA: /^[\u0980-\u09FF\s.]+$/,
  ENGLISH: /^[a-zA-Z\s.]+$/,
  MOBILE: /^01[3-9]\d{8}$/,
  NUMBER: /^\d+$/
};

export const toISODate = (dStr) => {
  if (!dStr) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(dStr)) return dStr;
  const d = new Date(dStr);
  if (isNaN(d.getTime())) return '';
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
};

// ------------------------------------------------------------------
// Class name normalisation
// Server stores "২য়"/"৩য়" with য + ় (U+09AF U+09BC); the original UI uses the
// single character য় (U+09DF). UI form is canonical inside the client.
// ------------------------------------------------------------------
export const toUiClass = (s) => String(s || '').replace(/\u09AF\u09BC/g, '\u09DF');
export const toServerClass = (s) => String(s || '').replace(/\u09DF/g, '\u09AF\u09BC');

export const CLASS_LIST_BN = ['প্লে', 'নার্সারি', 'কেজি', '১ম', '২য়', '৩য়', '৪র্থ', '৫ম', '৬ষ্ঠ', '৭ম', '৮ম', '৯ম', '১০ম'];

export const CLASS_EN_MAP = {
  'প্লে': 'Play', 'নার্সারি': 'Nursery', 'কেজি': 'KG',
  '১ম': 'One', '২য়': 'Two', '৩য়': 'Three', '৪র্থ': 'Four', '৫ম': 'Five',
  '৬ষ্ঠ': 'Six', '৭ম': 'Seven', '৮ম': 'Eight', '৯ম': 'Nine', '১০ম': 'Ten'
};

export const CLASS_CODE_MAP = {
  'প্লে': '99', 'নার্সারি': '00', 'কেজি': '98',
  '১ম': '01', '২য়': '02', '৩য়': '03', '৪র্থ': '04', '৫ম': '05',
  '৬ষ্ঠ': '06', '৭ম': '07', '৮ম': '08', '৯ম': '09', '১০ম': '10'
};

export const isSeniorClass = (classBn) => ['৯ম', '১০ম'].includes(toUiClass(classBn));

// ------------------------------------------------------------------
// Server -> UI
// ------------------------------------------------------------------
const dateOnly = (v) => {
  if (!v) return '';
  const s = String(v);
  return /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : s;
};

export const toUiStudent = (doc) => {
  if (!doc) return null;
  const addr = doc.presentAddress || {};
  return {
    _id: doc._id,
    ID: doc.studentCode,
    Time: doc.createdAt || doc.admissionDate || '',
    Session: doc.session || '',
    StudentNameBn: doc.fullNameBng || '',
    StudentNameEn: doc.fullNameEng || '',
    Roll: doc.roll,
    ClassBn: toUiClass(doc.classBn),
    ClassEn: doc.classEn || CLASS_EN_MAP[toUiClass(doc.classBn)] || '',
    Group: doc.group || '',
    Gender: doc.gender || '',
    BRN: doc.brnNumber || '',
    DOB: dateOnly(doc.dateOfBirth),
    BloodGroup: doc.bloodGroup && doc.bloodGroup !== 'N/A' ? doc.bloodGroup : '',
    FatherNameBn: doc.fathersNameBng || '',
    FatherNameEn: doc.fathersNameEng || '',
    MotherNameBn: doc.mothersNameBng || '',
    MotherNameEn: doc.mothersNameEng || '',
    WhatsApp: doc.phone || '',
    EmergencyNo: doc.emergencyContact?.phone || '',
    HouseNameBn: addr.houseNameBn || '',
    HouseNameEn: addr.houseNameEn || '',
    VillageBn: addr.villageBn || '',
    VillageEn: addr.villageEn || '',
    UnionBn: addr.unionBn || '',
    UnionEn: addr.unionEn || '',
    WardNo: addr.wardNo || '',
    UpazilaBn: addr.upazilaBn || '',
    UpazilaEn: addr.upazilaEn || '',
    DistrictBn: addr.districtBn || '',
    DistrictEn: addr.districtEn || '',
    ImageURL: doc.profilePicture?.url || '',
    Status: doc.status || 'Active',
    LastUpdated: doc.updatedAt ? new Date(doc.updatedAt).toLocaleString() : ''
  };
};

export const toUiStudents = (docs) => (Array.isArray(docs) ? docs.map(toUiStudent) : []);

// ------------------------------------------------------------------
// UI form -> Server payload (only fields the strict server schema knows)
// ------------------------------------------------------------------
const clean = (v) => String(v ?? '').replace(/\s+/g, ' ').trim();

export const buildAddress = (f) => ({
  houseNameBn: clean(f.houseNameBn),
  houseNameEn: clean(f.houseNameEn),
  villageBn: clean(f.villageBn),
  villageEn: clean(f.villageEn),
  unionBn: clean(f.unionBn),
  unionEn: clean(f.unionEn),
  wardNo: clean(f.wardNo),
  upazilaBn: clean(f.upazilaBn),
  upazilaEn: clean(f.upazilaEn),
  districtBn: clean(f.districtBn),
  districtEn: clean(f.districtEn),
  ...(f.divisionBn ? { divisionBn: clean(f.divisionBn) } : {}),
  ...(f.divisionEn ? { divisionEn: clean(f.divisionEn) } : {})
});

export const toServerPayload = (form, { isUpdate = false, imageUrl, publicId, migration = null } = {}) => {
  const classBn = toUiClass(form.classBn);
  const payload = {
    session: clean(form.sessionYear),
    fullNameBng: clean(form.studentNameBn),
    fullNameEng: clean(form.studentNameEn),
    gender: form.gender,
    classBn: toServerClass(classBn),
    classEn: CLASS_EN_MAP[classBn],
    roll: Number(form.roll),
    group: isSeniorClass(classBn) ? form.group || '' : '',
    brnNumber: clean(form.brn),
    dateOfBirth: form.dob,
    bloodGroup: form.bloodGroup || 'N/A',
    fathersNameBng: clean(form.fatherNameBn),
    fathersNameEng: clean(form.fatherNameEn),
    mothersNameBng: clean(form.motherNameBn),
    mothersNameEng: clean(form.motherNameEn),
    phone: clean(form.whatsappNumber),
    emergencyContact: {
      contactName: clean(form.fatherNameBn),
      relationship: 'Father',
      phone: clean(form.emergencyNumber)
    },
    presentAddress: buildAddress(form),
    profilePicture: { url: imageUrl, ...(publicId ? { publicId } : {}) }
  };

  if (!isUpdate) {
    // নতুন ভর্তিতে ১০ ডিজিটের আইডি সার্ভার নিজেই বানায় (একই অ্যালগরিদম)।
    // শিট থেকে মাইগ্রেশনে পুরনো আইডি অবিকৃত রাখা হয়।
    if (migration?.studentCode) {
      payload.studentCode = migration.studentCode;
      payload.migratedFromSheet = true;
      if (migration.admissionDate) payload.admissionDate = migration.admissionDate;
    }
  }
  return payload;
};

// ------------------------------------------------------------------
// Smart ID (same algorithm as the original form & the server)
// ------------------------------------------------------------------
export const generateStudentId = (sessionYear, dob, classBn, roll) => {
  if (!sessionYear || !dob || !classBn || !roll) return '';
  const dobYear = new Date(dob).getFullYear().toString().slice(-2);
  const classCode = CLASS_CODE_MAP[toUiClass(classBn)] || '00';
  const rollCode = String(roll).padStart(2, '0').slice(-2);
  return `${sessionYear}${dobYear}${classCode}${rollCode}`;
};

// ------------------------------------------------------------------
// Sibling detection (verbatim logic from original Index)
// ------------------------------------------------------------------
export const cleanFamilyName = (name) =>
  (name || '')
    .replace(/মোঃ|মো\.?|মোহাম্মদ|মুহাম্মদ|md\.?|MD\.?/gi, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

export const findSiblings = (list, detailData) => {
  if (!detailData) return [];

  const father = cleanFamilyName(detailData.FatherNameBn);
  const mother = cleanFamilyName(detailData.MotherNameBn);
  const phone = (detailData.WhatsApp || '').trim();

  return list
    .filter(s => {
      if (s.ID === detailData.ID) return false;
      let score = 0;
      if (father && cleanFamilyName(s.FatherNameBn) === father) score++;
      if (mother && cleanFamilyName(s.MotherNameBn) === mother) score++;
      if (phone && (s.WhatsApp || '').trim() === phone) score++;
      return score >= 2;
    })
    .sort((a, b) => {
      // বড় থেকে ছোট (জন্ম তারিখ অনুযায়ী), DOB না থাকলে ক্লাস অনুযায়ী
      const da = a.DOB ? new Date(a.DOB) : null;
      const db = b.DOB ? new Date(b.DOB) : null;
      if (da && db) return da - db;
      return (CLASS_ORDER[b.ClassBn] || 0) - (CLASS_ORDER[a.ClassBn] || 0);
    });
};

// ------------------------------------------------------------------
// Auth user (ERP) -> legacy UI user shape used by the original views
//   SuperAdmin/Admin -> role "Admin"      Teacher -> role "Class"
// ------------------------------------------------------------------
export const toUiUser = (user) => {
  if (!user) return null;
  const isAdmin = user.role === 'SuperAdmin' || user.role === 'Admin';
  const classBn = toUiClass(user.assignedClass);
  return {
    ...user,
    role: isAdmin ? 'Admin' : 'Class',
    erpRole: user.role,
    classBn,
    classEn: CLASS_EN_MAP[classBn] || '',
    canEditAssignedClass: user.canEditAssignedClass === true,
    displayName: user.fullNameEng || user.fullNameBng || user.name || user.teacherCode || ''
  };
};

// RBAC (spec §4)
export const canManageStudent = (uiUser, student) => {
  if (!uiUser) return false;
  if (uiUser.role === 'Admin') return true;
  return (
    uiUser.role === 'Class' &&
    uiUser.canEditAssignedClass === true &&
    !!uiUser.classBn &&
    (!student || student.ClassBn === uiUser.classBn)
  );
};

export const canCreateStudent = (uiUser) =>
  !!uiUser && (uiUser.role === 'Admin' || (uiUser.role === 'Class' && uiUser.canEditAssignedClass === true && !!uiUser.classBn));

// ------------------------------------------------------------------
// Server field name -> form field + step (for inline error mapping)
// ------------------------------------------------------------------
const FIELD_ROWS = [
  ['session', 'sessionYear', 1], ['studentCode', 'studentId', 1],
  ['fullNameBng', 'studentNameBn', 1], ['fullNameEng', 'studentNameEn', 1],
  ['roll', 'roll', 1], ['classBn', 'classBn', 1], ['group', 'group', 1],
  ['gender', 'gender', 1], ['brnNumber', 'brn', 1], ['dateOfBirth', 'dob', 1],
  ['bloodGroup', 'bloodGroup', 1], ['admissionDate', 'dob', 1],
  ['fathersNameBng', 'fatherNameBn', 2], ['fathersNameEng', 'fatherNameEn', 2],
  ['mothersNameBng', 'motherNameBn', 2], ['mothersNameEng', 'motherNameEn', 2],
  ['phone', 'whatsappNumber', 2], ['emergencyContact.phone', 'emergencyNumber', 2],
  ['emergencyContact.contactName', 'emergencyNumber', 2], ['emergencyContact.relationship', 'emergencyNumber', 2],
  ['presentAddress.houseNameBn', 'houseNameBn', 3], ['presentAddress.houseNameEn', 'houseNameEn', 3],
  ['presentAddress.villageBn', 'villageBn', 3], ['presentAddress.villageEn', 'villageEn', 3],
  ['presentAddress.unionBn', 'unionBn', 3], ['presentAddress.unionEn', 'unionEn', 3],
  ['presentAddress.wardNo', 'wardNo', 3],
  ['presentAddress.upazilaBn', 'upazilaBn', 3], ['presentAddress.upazilaEn', 'upazilaEn', 3],
  ['presentAddress.districtBn', 'districtBn', 3], ['presentAddress.districtEn', 'districtEn', 3],
  ['profilePicture.url', 'imageUrl', 4], ['profilePicture', 'imageUrl', 4]
];
const SERVER_FIELD_MAP = Object.fromEntries(FIELD_ROWS.map(([s, f, step]) => [s, { field: f, step }]));

export const mapServerFieldErrors = (fieldErrors = []) => {
  const errors = {};
  let firstStep = null;
  const unmapped = [];
  fieldErrors.forEach(({ field, message }) => {
    const hit = SERVER_FIELD_MAP[field] || SERVER_FIELD_MAP[String(field || '').replace(/\.\d+/g, '')];
    if (!hit) { unmapped.push(message); return; }
    if (!errors[hit.field]) errors[hit.field] = message;
    if (firstStep === null || hit.step < firstStep) firstStep = hit.step;
  });
  return { errors, firstStep, unmapped };
};

// ------------------------------------------------------------------
// Sheet (legacy) autoFillData -> UI form state (for migration)
// ------------------------------------------------------------------
export const legacyToFormState = (a) => ({
  sessionYear: a.session || '',
  studentId: a.studentCode || '',
  studentNameBn: a.fullNameBng || '',
  studentNameEn: a.fullNameEng || '',
  gender: a.gender || '',
  roll: a.roll || '',
  classBn: toUiClass(a.classBn),
  group: a.group || '',
  brn: a.brnNumber || '',
  dob: dateOnly(a.dateOfBirth),
  bloodGroup: a.bloodGroup && a.bloodGroup !== 'N/A' ? a.bloodGroup : '',
  fatherNameBn: a.fathersNameBng || '',
  fatherNameEn: a.fathersNameEng || '',
  motherNameBn: a.mothersNameBng || '',
  motherNameEn: a.mothersNameEng || '',
  whatsappNumber: a.phone || '',
  emergencyNumber: a.emergencyContact?.phone || '',
  houseNameBn: a.presentAddress?.houseNameBn || '',
  houseNameEn: a.presentAddress?.houseNameEn || '',
  villageBn: a.presentAddress?.villageBn || '',
  villageEn: a.presentAddress?.villageEn || '',
  unionBn: a.presentAddress?.unionBn || '',
  unionEn: a.presentAddress?.unionEn || '',
  wardNo: a.presentAddress?.wardNo || '',
  upazilaBn: a.presentAddress?.upazilaBn || '',
  upazilaEn: a.presentAddress?.upazilaEn || '',
  districtBn: a.presentAddress?.districtBn || '',
  districtEn: a.presentAddress?.districtEn || '',
  imageUrl: a.profilePicture?.url || ''
});
