const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const mongoSanitize = require('express-mongo-sanitize');
const hpp = require('hpp');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');
const ApiError = require('./utils/ApiError');
const errorHandler = require('./middlewares/error.middleware');

const authRoutes = require('./routes/auth.routes');
const teacherRoutes = require('./routes/teacher.routes');
const studentRoutes = require('./routes/student.routes');
const attendanceRoutes = require('./routes/attendance.routes');
const payrollRoutes = require('./routes/payroll.routes');
const uploadRoutes = require('./routes/upload.routes');
const systemRoutes = require('./routes/system.routes');
const resultsRoutes = require('./routes/results.routes');
const { zkTecoHandshake, zkTecoReceiveLogs } = require('./controllers/attendance.controller');

const app = express();
const allowedOrigins = (process.env.CLIENT_URL || 'http://localhost:5173,http://127.0.0.1:5173')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);

app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({
    origin: (origin, callback) => {
        if (!origin || allowedOrigins.includes(origin)) {
            callback(null, true);
            return;
        }

        callback(new Error('CORS policy denied this origin.'));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
}));

const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    message: {
        success: false,
        statusCode: 429,
        message: 'অতিরিক্ত রিকোয়েস্ট পাঠানো হয়েছে! ১৫ মিনিট পর চেষ্টা করুন।'
    },
    standardHeaders: true,
    legacyHeaders: false,
});
app.use('/api', apiLimiter);
app.use(
    '/api/v1/results',
    express.text({ type: ['text/plain', 'application/json'], limit: '5mb' }),
    resultsRoutes
);

app.use(express.json({ limit: '50kb' }));
app.use(express.urlencoded({ extended: true, limit: '50kb' }));
app.use(express.text({ type: ['text/plain', 'application/octet-stream'], limit: '200kb' }));
app.use(cookieParser());
app.use(mongoSanitize());
app.use(hpp());

if (process.env.NODE_ENV === 'development') {
    app.use(morgan('dev'));
}

app.get('/health', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'ARDM Zero-Maintenance Enterprise ERP Server is healthy 🛡️',
        activeRoutes: [
            '/api/v1/auth',
            '/api/v1/teachers',
            '/api/v1/students',
            '/api/v1/attendance',
            '/api/v1/payroll',
            '/api/v1/upload',
            '/api/v1/system',
            '/api/v1/results',
            '/iclock/cdata'
        ],
        timezone: process.env.TIMEZONE,
        serverTime: new Date().toLocaleString('en-US', { timeZone: process.env.TIMEZONE })
    });
});

// ZKTeco K40 Native ADMS Routes
app.get('/iclock/cdata', zkTecoHandshake);
app.post('/iclock/cdata', zkTecoReceiveLogs);
app.get('/iclock/getrequest', (req, res) => {
    res.status(200).type('text/plain').send('OK');
});

// Enterprise API v1 Routes
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/teachers', teacherRoutes);
app.use('/api/v1/students', studentRoutes);
app.use('/api/v1/attendance', attendanceRoutes);
app.use('/api/v1/payroll', payrollRoutes);
app.use('/api/v1/upload', uploadRoutes);
app.use('/api/v1/system', systemRoutes);

app.all('*', (req, res, next) => {
    next(new ApiError(404, 'অনুরোধ করা সেবাটি পাওয়া যায়নি। ঠিকানা যাচাই করে আবার চেষ্টা করুন।'));
});

app.use(errorHandler);

module.exports = app;
